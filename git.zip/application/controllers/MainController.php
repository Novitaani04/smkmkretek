<?php

    class MainController extends CI_Controller
    {
        public function index()
        {
            redirect('front/Home');
        }
    }

?>